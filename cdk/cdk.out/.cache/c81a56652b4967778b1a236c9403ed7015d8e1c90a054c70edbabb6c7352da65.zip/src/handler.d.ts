export declare const handler: (event: any, context: any) => Promise<any>;
