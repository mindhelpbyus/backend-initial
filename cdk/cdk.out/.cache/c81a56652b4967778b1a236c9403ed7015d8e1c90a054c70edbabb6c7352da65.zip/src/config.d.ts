import { DynamoDBDocumentClient } from "@aws-sdk/lib-dynamodb";
export declare const getDynamoDBClient: () => DynamoDBDocumentClient;
